/*
 * ZenBot AI - Powered by Claude API
 * CodeAlpha Internship Task 3
 * @author ahmed
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.*;


public class chatbotApp extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
        java.util.logging.Logger.getLogger(chatbotApp.class.getName());

    // ============================================================
    // PASTE YOUR API KEY HERE BETWEEN THE QUOTES
    // ============================================================
  private static final String API_KEY = "YOUR_GROQ_API_KEY_HERE";
    // ============================================================

    private static final String API_URL = "";
    private StringBuilder chatHistory = new StringBuilder();
    private java.util.List<String> conversationHistory = new ArrayList<>();

    // ===================== COLORS =====================
    private static final Color C_BG       = new Color(15, 23, 42);
    private static final Color C_HEADER   = new Color(15, 23, 42);
    private static final Color C_TEAL     = new Color(20, 184, 166);
    private static final Color C_NAVY     = new Color(15, 23, 42);
    private static final Color C_INPUT_BG = new Color(30, 41, 59);
    private static final Color C_CHIP_BG  = new Color(30, 41, 59);

    // ===================== CONSTRUCTOR =====================
    public chatbotApp() {
        initComponents();
        styleComponents();
        showWelcomeMessage();
    }

    // ===================== CLAUDE API CALL =====================
    private String callClaudeAPI(String userMessage) {
        try {
            // Build conversation history as JSON
           String escapedMsg = userMessage
    .replace("\\", "\\\\")
    .replace("\"", "\\\"")
    .replace("\n", "\\n")
    .replace("\r", "\\r");

StringBuilder messagesJson = new StringBuilder("[");
boolean first = true;
for (String msg : conversationHistory) {
    if (!first) messagesJson.append(",");
    messagesJson.append(msg);
    first = false;
}
if (!conversationHistory.isEmpty()) messagesJson.append(",");
messagesJson.append("{\"role\":\"user\",\"content\":\"")
    .append(escapedMsg).append("\"}");
messagesJson.append("]");

            // Build request body
           String requestBody = "{"
   + "\"model\":\"llama-3.3-70b-versatile\","
    + "\"max_tokens\":1000,"
    + "\"messages\":["
    + "{\"role\":\"system\",\"content\":\"You are ZenBot, a friendly and helpful AI assistant. "
    + "You were built by Ahmed as part of the CodeAlpha Java Programming Internship 2026. "
    + "You are running inside a Java Swing desktop application. "
    + "Keep responses concise, friendly and helpful. "
    + "When answering, use simple HTML formatting: use <b> for bold, <br> for new lines. "
    + "Do not use markdown like ** or ##. Use <b>text</b> instead of **text**.\"},"
    + messagesJson.toString().substring(1)
    + "}";

            // Build HTTP request
       java.net.http.HttpClient client = java.net.http.HttpClient.newBuilder()
    .version(java.net.http.HttpClient.Version.HTTP_1_1)
    .build();
java.net.http.HttpRequest request = java.net.http.HttpRequest.newBuilder()
    .uri(new java.net.URI("https", "api.groq.com", "/openai/v1/chat/completions", null))
    .header("Content-Type", "application/json")
   .header("Authorization", "Bearer " + API_KEY)
    
    .POST(java.net.http.HttpRequest.BodyPublishers.ofString(requestBody))
    .build();

java.net.http.HttpResponse<String> response = client.send(request,
    java.net.http.HttpResponse.BodyHandlers.ofString());

String body = response.body();

            if (response.statusCode() == 200) {
                // Parse the response text from JSON
                String marker = "\"content\":\"";
int start = body.indexOf(marker);
if (start != -1) {
    start += marker.length();
    int end = body.indexOf("\",\"role\"", start);
    if (end == -1) end = body.indexOf("\"}", start);
                    if (end != -1) {
                       String text = body.substring(start, end)
    .replace("\\n", "<br>")
    .replace("\\\"", "\"")
    .replace("\\\\", "\\")
    .replace("\\u003cb\\u003e", "<b>")
    .replace("\\u003c/b\\u003e", "</b>")
    .replace("\\u003cbr\\u003e", "<br>")
    .replace("\\u003c/br\\u003e", "<br>")
    .replace("\\u003cp\\u003e", "<br>")
    .replace("\\u003c/p\\u003e", "<br>")
    .replace("\\u003cli\\u003e", "<br>• ")
    .replace("\\u003c/li\\u003e", "")
    .replace("\\u003cul\\u003e", "")
    .replace("\\u003c/ul\\u003e", "")
    .replace("**", "")
    .replace("##", "")
    .replace("# ", "");

                        // Save to conversation history
                        String escapedUser = userMessage.replace("\\","\\\\").replace("\"","\\\"");
                        String escapedReply = text.replace("\\","\\\\").replace("\"","\\\"").replace("<br>","\\n");
                        conversationHistory.add("{\"role\":\"user\",\"content\":\"" + escapedUser + "\"}");
                        conversationHistory.add("{\"role\":\"assistant\",\"content\":\"" + escapedReply + "\"}");

                        // Keep history to last 10 exchanges (20 messages)
                        while (conversationHistory.size() > 20) {
                            conversationHistory.remove(0);
                            conversationHistory.remove(0);
                        }

                        return text;
                    }
                }
                return "I received a response but could not parse it. Please try again!";
            } else if (response.statusCode() == 401) {
    return "<b>API Error 401</b><br>Response: " + body;
            } else if (response.statusCode() == 429) {
                return "<b>Rate Limit Reached!</b><br>Too many requests. Please wait a moment and try again.";
            } else if (response.statusCode() == 402) {
                return "<b>Credits Exhausted!</b><br>Your free API credits have run out.<br>"
                    + "Visit console.anthropic.com to add credits.";
           } else {
    return "API Error " + response.statusCode() + "<br>Details: " + body;
}

        } catch (java.net.ConnectException e) {
            return "<b>No Internet Connection!</b><br>Please check your internet and try again.";
        } catch (Exception e) {
            return "<b>Error connecting to AI:</b><br>" + e.getMessage()
                + "<br>Please check your internet connection.";
        }
    }

    // ===================== UI STYLING =====================
    private void styleComponents() {
        setTitle("ZenBot AI - Powered by Claude");
        setResizable(false);
        getContentPane().setBackground(C_BG);

        headerPanel.setBackground(C_HEADER);

        botIconLabel.setText("Z");
        botIconLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        botIconLabel.setForeground(C_TEAL);
        botIconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        botIconLabel.setOpaque(true);
        botIconLabel.setBackground(new Color(30, 41, 59));
        botIconLabel.setBorder(BorderFactory.createLineBorder(C_TEAL, 2));

        botNameLabel.setText("  ZenBot AI");
        botNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botNameLabel.setForeground(Color.WHITE);

        statusLabel.setText("  Powered by Claude AI  •  Online");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(C_TEAL);

        chatPane.setEditable(false);
        chatPane.setContentType("text/html");
        chatPane.setBackground(C_BG);
        jScrollPane2.setBorder(BorderFactory.createLineBorder(new Color(30, 41, 59), 1));
        jScrollPane2.getViewport().setBackground(C_BG);
        jScrollPane2.setBackground(C_BG);

        messageField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        messageField.setBackground(C_INPUT_BG);
        messageField.setForeground(Color.WHITE);
        messageField.setCaretColor(C_TEAL);
        messageField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(C_TEAL, 2),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));

        sendButton.setText("Send");
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sendButton.setBackground(C_TEAL);
        sendButton.setForeground(C_NAVY);
        sendButton.setFocusPainted(false);
        sendButton.setBorderPainted(false);
        sendButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        clearButton.setText("Clear");
        clearButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        clearButton.setBackground(new Color(239, 68, 68));
        clearButton.setForeground(Color.WHITE);
        clearButton.setFocusPainted(false);
        clearButton.setBorderPainted(false);
        clearButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        styleChip(btn1, "Hi!");
        styleChip(btn2, "Tell me a joke");
        styleChip(btn3, "What time is it?");
        styleChip(btn4, "Fun fact");
        styleChip(btn5, "Who are you?");
    }

    private void styleChip(JButton btn, String text) {
        btn.setText(text);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn.setBackground(C_CHIP_BG);
        btn.setForeground(C_TEAL);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(C_TEAL, 1));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    // ===================== CHAT METHODS =====================
    private void showWelcomeMessage() {
        chatHistory = new StringBuilder();
        conversationHistory.clear();
        chatHistory.append("<html><body style='font-family:Segoe UI,Arial;font-size:13px;"
            + "background:#0F172A;margin:10px;color:#E2E8F0;'>");
        appendBotBubble(
            "Hello! I am <b>ZenBot AI</b>, powered by <b>Claude AI</b>!<br>"
            + "I can answer <b>literally anything</b> you ask — just like ChatGPT!<br>"
            + "Ask me about coding, science, history, math, advice, or anything else!<br>"
            + "I also remember our conversation context. Let's chat!"
        );
    }

    private void appendBotBubble(String message) {
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"));
        chatHistory.append(
            "<table width='100%' cellpadding='0' cellspacing='8'><tr>"
            + "<td width='40' valign='top'>"
            + "<div style='width:38px;height:38px;border-radius:50%;"
            + "background:#1E293B;text-align:center;line-height:38px;"
            + "color:#14B8A6;font-weight:bold;font-size:18px;"
            + "border:2px solid #14B8A6;'>Z</div></td>"
            + "<td valign='top'>"
            + "<div style='background:#1E293B;border:1px solid #14B8A6;"
            + "border-radius:4px 18px 18px 18px;padding:12px 16px;"
            + "max-width:82%;display:inline-block;color:#E2E8F0;line-height:1.7;'>"
            + message + "</div><br>"
            + "<span style='font-size:10px;color:#64748B;margin-left:4px;'>"
            + "ZenBot • " + time + "</span>"
            + "</td><td></td></tr></table>"
        );
        refreshChat();
    }

    private void appendUserBubble(String message) {
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"));
        chatHistory.append(
            "<table width='100%' cellpadding='0' cellspacing='8'><tr>"
            + "<td></td>"
            + "<td align='right' valign='top'>"
            + "<div style='background:#0891B2;"
            + "border-radius:18px 4px 18px 18px;padding:12px 16px;"
            + "max-width:82%;display:inline-block;color:white;"
            + "font-weight:500;line-height:1.7;'>"
            + message + "</div><br>"
            + "<div style='text-align:right'>"
            + "<span style='font-size:10px;color:#64748B;margin-right:4px;'>"
            + "You • " + time + "</span></div>"
            + "</td>"
            + "<td width='40' valign='top'>"
            + "<div style='width:38px;height:38px;border-radius:50%;"
            + "background:#0891B2;text-align:center;line-height:38px;"
            + "color:white;font-weight:bold;font-size:16px;'>U</div></td>"
            + "</tr></table>"
        );
        refreshChat();
    }

    private void appendTypingIndicator() {
        chatHistory.append(
            "<table width='100%' cellpadding='0' cellspacing='8' id='typing'><tr>"
            + "<td width='40' valign='top'>"
            + "<div style='width:38px;height:38px;border-radius:50%;"
            + "background:#1E293B;text-align:center;line-height:38px;"
            + "color:#14B8A6;font-weight:bold;font-size:18px;"
            + "border:2px solid #14B8A6;'>Z</div></td>"
            + "<td valign='top'>"
            + "<div style='background:#1E293B;border:1px solid #475569;"
            + "border-radius:4px 18px 18px 18px;padding:12px 16px;"
            + "display:inline-block;color:#94A3B8;font-style:italic;'>"
            + "ZenBot is thinking...</div>"
            + "</td><td></td></tr></table>"
        );
        refreshChat();
    }

    private void refreshChat() {
        String html = chatHistory + "<br><br></body></html>";
        chatPane.setText(html);
        SwingUtilities.invokeLater(() ->
            jScrollPane2.getVerticalScrollBar().setValue(
                jScrollPane2.getVerticalScrollBar().getMaximum()));
    }

    // ===================== SEND MESSAGE =====================
    private void sendMessage() {
        String userText = messageField.getText().trim();
        if (userText.isEmpty()) return;

        // Check API key
        if (API_KEY.equals("YOUR_API_KEY_HERE")) {
            appendBotBubble("<b>API Key Missing!</b><br>"
                + "Open chatbotApp.java in NetBeans and find this line:<br>"
                + "<b>private static final String API_KEY = \"YOUR_API_KEY_HERE\";</b><br>"
                + "Replace YOUR_API_KEY_HERE with your actual API key from console.anthropic.com");
            return;
        }

        appendUserBubble(userText);
        messageField.setText("");
        sendButton.setEnabled(false);
        messageField.setEnabled(false);

        // Show typing indicator
        int historyLengthBeforeTyping = chatHistory.length();
        appendTypingIndicator();

        // Call API in background thread
        final String text = userText;
        new Thread(() -> {
            String response = callClaudeAPI(text);

            SwingUtilities.invokeLater(() -> {
                // Remove typing indicator
                chatHistory.setLength(historyLengthBeforeTyping);
                // Add real response
                appendBotBubble(response);
                sendButton.setEnabled(true);
                messageField.setEnabled(true);
                messageField.requestFocus();
            });
        }).start();
    }

    // ===================== INIT COMPONENTS =====================
    @SuppressWarnings("unchecked")
    private void initComponents() {
        headerPanel  = new javax.swing.JPanel();
        botIconLabel = new javax.swing.JLabel();
        botNameLabel = new javax.swing.JLabel();
        statusLabel  = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        chatPane     = new javax.swing.JEditorPane();
        messageField = new javax.swing.JTextField();
        sendButton   = new javax.swing.JButton();
        clearButton  = new javax.swing.JButton();
        btn1 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(620, 780));

        headerPanel.setBackground(new java.awt.Color(15, 23, 42));
        javax.swing.GroupLayout hpl = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(hpl);
        hpl.setHorizontalGroup(
            hpl.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hpl.createSequentialGroup()
                .addGap(16)
                .addComponent(botIconLabel,
                    javax.swing.GroupLayout.PREFERRED_SIZE, 52,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12)
                .addGroup(hpl.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botNameLabel)
                    .addComponent(statusLabel))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        hpl.setVerticalGroup(
            hpl.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hpl.createSequentialGroup()
                .addGap(14)
                .addComponent(botIconLabel,
                    javax.swing.GroupLayout.PREFERRED_SIZE, 48,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14))
            .addGroup(hpl.createSequentialGroup()
                .addGap(16)
                .addComponent(botNameLabel,
                    javax.swing.GroupLayout.PREFERRED_SIZE, 26,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4)
                .addComponent(statusLabel)
                .addGap(16))
        );

        chatPane.setEditable(false);
        chatPane.setContentType("text/html");
        jScrollPane2.setViewportView(chatPane);

        sendButton.setText("Send");
        sendButton.addActionListener(this::sendButtonActionPerformed);
        clearButton.setText("Clear");
        clearButton.addActionListener(this::clearButtonActionPerformed);
        btn1.setText("Hi!"); btn1.addActionListener(this::btn1ActionPerformed);
        btn2.setText("Joke"); btn2.addActionListener(this::btn2ActionPerformed);
        btn3.setText("Time"); btn3.addActionListener(this::btn3ActionPerformed);
        btn4.setText("Fact"); btn4.addActionListener(this::btn4ActionPerformed);
        btn5.setText("Who are you?"); btn5.addActionListener(this::btn5ActionPerformed);
        messageField.addActionListener(this::messageFieldActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(headerPanel,
                javax.swing.GroupLayout.DEFAULT_SIZE,
                javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(12).addComponent(jScrollPane2).addGap(12))
            .addGroup(layout.createSequentialGroup()
                .addGap(12).addComponent(messageField)
                .addGap(8).addComponent(sendButton,
                    javax.swing.GroupLayout.PREFERRED_SIZE, 90,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6).addComponent(clearButton,
                    javax.swing.GroupLayout.PREFERRED_SIZE, 80,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12))
            .addGroup(layout.createSequentialGroup()
                .addGap(12).addComponent(btn1)
                .addGap(6).addComponent(btn2)
                .addGap(6).addComponent(btn3)
                .addGap(6).addComponent(btn4)
                .addGap(6).addComponent(btn5)
                .addGap(12))
        );
        layout.setVerticalGroup(
            layout.createSequentialGroup()
            .addComponent(headerPanel,
                javax.swing.GroupLayout.PREFERRED_SIZE,
                javax.swing.GroupLayout.DEFAULT_SIZE,
                javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(8)
            .addComponent(jScrollPane2,
                javax.swing.GroupLayout.DEFAULT_SIZE, 470, Short.MAX_VALUE)
            .addGap(8)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(messageField,
                    javax.swing.GroupLayout.PREFERRED_SIZE, 46,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(sendButton,
                    javax.swing.GroupLayout.PREFERRED_SIZE, 46,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(clearButton,
                    javax.swing.GroupLayout.PREFERRED_SIZE, 46,
                    javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(8)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btn1, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn2, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn3, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn4, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btn5, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                    javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(12)
        );
        pack();
    }

    // ===================== ACTIONS =====================
    private void sendButtonActionPerformed(java.awt.event.ActionEvent e)   { sendMessage(); }
    private void messageFieldActionPerformed(java.awt.event.ActionEvent e)  { sendMessage(); }
    private void clearButtonActionPerformed(java.awt.event.ActionEvent e)   { showWelcomeMessage(); }
    private void btn1ActionPerformed(java.awt.event.ActionEvent e) { messageField.setText("Hello!"); sendMessage(); }
    private void btn2ActionPerformed(java.awt.event.ActionEvent e) { messageField.setText("Tell me a funny programming joke"); sendMessage(); }
    private void btn3ActionPerformed(java.awt.event.ActionEvent e) { messageField.setText("What is the current time?"); sendMessage(); }
    private void btn4ActionPerformed(java.awt.event.ActionEvent e) { messageField.setText("Tell me an amazing fact"); sendMessage(); }
    private void btn5ActionPerformed(java.awt.event.ActionEvent e) { messageField.setText("Who are you?"); sendMessage(); }

    // ===================== MAIN =====================
    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info :
                    javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> {
            chatbotApp frame = new chatbotApp();
            frame.setSize(620, 780);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            frame.toFront();
        });
    }

    // ===================== VARIABLES =====================
    private javax.swing.JLabel      botIconLabel;
    private javax.swing.JLabel      botNameLabel;
    private javax.swing.JLabel      statusLabel;
    private javax.swing.JPanel      headerPanel;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JEditorPane chatPane;
    private javax.swing.JTextField  messageField;
    private javax.swing.JButton     sendButton;
    private javax.swing.JButton     clearButton;
    private javax.swing.JButton     btn1, btn2, btn3, btn4, btn5;
}